package exams.second;

public class Circle extends Shape {
	private double radius;
	
	public Circle() {
		super("cirlce");
		this.radius =1;
	}
	public Circle(double radius) {
		super("cirlce");
		this.radius = radius;
	}
	public double getRadius() {
		return radius;
	}
	
	public void setRadius(double radius){
		if(radius > 0) {
			this.radius = radius;
		}else {
			System.out.println("Enter positive radius");
		}
	}
	
	public boolean equals(Object obj) {
		if(super.equals(obj)) {
			Circle circle = (Circle) obj;
			if(circle.getRadius() == radius) {
				return true;
			}
		}
		return false;
	}
	
	public String toString() {
		return super.toString() + " Radius: " + radius;
	}
	
	@Override
	public double area() {
		return(radius * radius * 3.14);
	}

	@Override
	public double perimeter() {
		return (2 * radius * 3.14);
	}

}

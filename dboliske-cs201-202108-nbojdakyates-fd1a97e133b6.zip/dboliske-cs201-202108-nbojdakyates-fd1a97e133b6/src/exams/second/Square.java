package exams.second;

public class Square extends Shape {
	private double side;
	
	public Square(){
		super("square");
		this.side = 1;
	}
	public Square(double side) {
		super("square");
		this.side = side;
	}
	public void setSide(double side) {
		if(side >0) {
			this.side = side;
		}else {
			System.out.println("Enter positive side");
		}
	}
	public double getSide() {
		return side;
	}
	
	public boolean equals(Object obj) {
		if(super.equals(obj)) {
			Square square = (Square) obj;
			if(square.getSide() == side) {
				return true;
			}
		}
		return false;
	}
	public String toString() {
		return super.toString() + " Side " + side;
	}
	
	@Override
	public double perimeter() {
		return (4*side);
	}

	@Override
	public double area() {
		return (side*side);
	}

}

package exams.second;

public class Sort {
	
	public static void main(String[] args) {
		String[] words = {"briefly", "mugwump", "articulation", "sync", "skein", "moire", "advisability", "varmint", "mandibular", "evergreen"};
		
		words = bubbleSort(words);
		
		for(int i=0;i<words.length;i++) {
			System.out.print(words[i] + " ");
		}
		

	}
	public static String[] bubbleSort(String[] words) {
		boolean done = false;
		
		do {
			done = true;
			for(int i=0;i<words.length-1;i++) {
				if(words[i+1].compareToIgnoreCase(words[i]) < 0) {
					String temp = words[i+1];
					words[i+1] = words[i];
					words[i] = temp;
					done =false;
				}
			}
		}while(!done);
		
		return words;
	}
	
}

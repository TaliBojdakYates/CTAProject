package exams.second;

import java.util.Scanner;

public class Search {
	public static void main(String[] args) {
		int[] array =  {8, 13, 18, 24, 31, 64, 65, 71, 73, 87};
		Scanner input = new Scanner(System.in);
		
		System.out.println("Search for a term");
		int userInput = input.nextInt();
		int index = search(array,userInput);
		
		if(index == -1) {
			System.out.println(userInput + " was not found");
		}else {
			System.out.println(userInput + " found at index " + index);
		}
		input.close();
	}
	
	public static int search(int[] array, int value) {
		return search(array, value, 0, array.length);
	}
	public static int search(int[] array, int value, int start, int end) {
		if(start>=end) {
			return -1;
		}
		
		int middle = (start+end)/2;
		if(array[middle] < value) {
			return search(array, value,middle+1,end);
		}else if(array[middle] > value) {
			return search(array,value,start,middle);
		}
		
		return middle;	
	}
}

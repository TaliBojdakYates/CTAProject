# Total

98/100

# Break Down

- Question One: 23/25

  - Superclass: 5/5
  - Subclasses: 8/10
  - Variables: 5/5
  - Methods: 5/5

- Question Two: 25/25

  - Compiles: 5/5
  - ArrayLists: 5/5
  - Input: 5/5
  - Results: 10/10

- Question Three: 25/25
  - Compiles: 5/5
  - Bubble Sort: 10/10
  - Results: 10/10

- Question Four: 25/25
  - Compiles: 5/5
  - Binary Search: 10/10
  - Input: 5/5
  - Results: 5/5

# Comments

1. Good, but your Square and Circle don't have any validation in their non-default constructors.
2. Way more complicated than it needed to be (just have an array of counts), but works.
3. Good
4. Good

package exams.second;

public class firstQuestionTest {

	public static void main(String[] args) {
		Circle cirlce = new Circle(1);
		Circle cirle2 = new Circle(1);
		
		System.out.println(cirlce.equals(cirle2));
		System.out.println(cirlce.area());
		System.out.println(cirlce.perimeter());
		
		
		Square square = new Square(4);
		Square square2 = new Square(4);
		System.out.println(square.equals(square2));
		System.out.println(square.area());
		System.out.println(square.perimeter());
		
		System.out.println(square.toString());
		System.out.println(cirlce.toString());
		
		
	}

}

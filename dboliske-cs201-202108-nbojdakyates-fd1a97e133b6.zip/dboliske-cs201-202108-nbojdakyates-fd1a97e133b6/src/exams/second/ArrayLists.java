package exams.second;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayLists {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		ArrayList<String> words = new ArrayList<>();
		ArrayList<Character> firstChar = new ArrayList<>();
		ArrayList<Character> a = new ArrayList<>();
		ArrayList<Character> b = new ArrayList<>();
		ArrayList<Character> c = new ArrayList<>();
		ArrayList<Character> d = new ArrayList<>();
		ArrayList<Character> e = new ArrayList<>();
		ArrayList<Character> f = new ArrayList<>();
		ArrayList<Character> g = new ArrayList<>();
		ArrayList<Character> h = new ArrayList<>();
		ArrayList<Character> i = new ArrayList<>();
		ArrayList<Character> j = new ArrayList<>();
		ArrayList<Character> k = new ArrayList<>();
		ArrayList<Character> l = new ArrayList<>();
		ArrayList<Character> m = new ArrayList<>();
		ArrayList<Character> n = new ArrayList<>();
		ArrayList<Character> o = new ArrayList<>();
		ArrayList<Character> p = new ArrayList<>();
		ArrayList<Character> q = new ArrayList<>();
		ArrayList<Character> r = new ArrayList<>();
		ArrayList<Character> s = new ArrayList<>();
		ArrayList<Character> t = new ArrayList<>();
		ArrayList<Character> u = new ArrayList<>();
		ArrayList<Character> v = new ArrayList<>();
		ArrayList<Character> w = new ArrayList<>();
		ArrayList<Character> x = new ArrayList<>();
		ArrayList<Character> y = new ArrayList<>();
		ArrayList<Character> z = new ArrayList<>();
		
		boolean quit = false;
		
		do {
			System.out.println("Enter word of Done to quit");
			String word = input.nextLine();
			if(word.equalsIgnoreCase("done")) {
				quit=true;
			}else {
				String lowerCase = word.toLowerCase();
				words.add(lowerCase);
			}
		}while(!quit);
		
		
		for(int index =0;index<words.size();index++) {
			firstChar.add(words.get(index).charAt(0));
		}
		for(int value=0;value<firstChar.size();value++) {
			switch(firstChar.get(value)) {
				case 'a':
					a.add('a');
					break;
				case 'b':
					b.add('b');
					break;
				case 'c':
					c.add('c');
					break;
				case 'd':
					d.add('d');
					break;
				case 'e':
					e.add('e');
					break;
				case 'f':
					f.add('f');
					break;
				case 'g':
					g.add('g');
					break;
				case 'h':
					h.add('h');
					break;
				case 'i':
					i.add('i');
					break;
					
				case 'j':
					j.add('j');
					break;
				case 'k':
					k.add('k');
					break;
				case 'l':
					l.add('l');
					break;
				case 'm':
					m.add('m');
					break;
				case 'n':
					n.add('n');
					break;
				case 'o':
					o.add('o');
					break;
				case 'p':
					p.add('p');
					break;
				case 'q':
					q.add('q');
					break;
				case 'r':
					r.add('r');
					break;
				case 's':
					s.add('s');
					break;
				case 't':
					t.add('t');
					break;
				case 'u':
					u.add('u');
					break;
				case 'v':
					v.add('v');
					break;
				case 'w':
					w.add('w');
					break;
				case 'x':
					x.add('x');
					break;
				case 'y':
					y.add('y');
					break;
					
				case 'z':
					z.add('z');
					break;
				default:
					System.out.println("Does not start with letter");
					break;
				
			}
			
		}
		System.out.println("A -" +a.size());
		System.out.println("B -" +b.size());
		System.out.println("C -" +c.size());
		System.out.println("D -" +d.size());
		System.out.println("E -" +e.size());
		System.out.println("F -" +f.size());
		System.out.println("G -" +g.size());
		System.out.println("H -" +h.size());
		System.out.println("I -" +i.size());
		System.out.println("J -" +j.size());
		System.out.println("K -" +k.size());
		System.out.println("L -" +l.size());
		System.out.println("M -" +m.size());
		System.out.println("N -" +n.size());
		System.out.println("O -" +o.size());
		System.out.println("P -" +p.size());
		System.out.println("Q -" +q.size());
		System.out.println("R -" +r.size());
		System.out.println("S -" +s.size());
		System.out.println("T -" +t.size());
		System.out.println("U -" +u.size());
		System.out.println("V -" +v.size());
		System.out.println("W -" +w.size());
		System.out.println("X -" +x.size());
		System.out.println("Y -" +y.size());
		System.out.println("Z -" +z.size());
		
		
	}
	//I know there has to be a better solution but forgot way to do it

}

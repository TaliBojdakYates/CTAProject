package exams.second;

public abstract class Shape {
	protected String name;
	
	public Shape() {
		name = "line";
	}
	public Shape(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Shape)) {
			return false;
		}
		Shape shape = (Shape) obj;
				
		if(shape.getName().equalsIgnoreCase(name)) {
			return true;
		}
		return false;
	}
	public String toString() {
		return "Shape name: " + name;
	}
	public abstract double perimeter();
	public abstract double area();
	

}

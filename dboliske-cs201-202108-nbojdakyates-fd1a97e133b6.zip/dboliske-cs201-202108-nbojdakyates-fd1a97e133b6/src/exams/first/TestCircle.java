package exams.first;

public class TestCircle {

	public static void main(String[] args) {
//		Circle circle1 = new Circle();
//		System.out.println(circle1.getRadius());
//		System.out.println(circle1.area());
//		System.out.println(circle1.circumference());
//		
//		
//		circle1.setRadius(2);
//		System.out.println(circle1.getRadius());
//		System.out.println(circle1.area());
//		System.out.println(circle1.circumference());
//		
	
		
		
		Circle circle2 = new Circle(2);
		System.out.println(circle2.getRadius());
		System.out.println(circle2.area());
		System.out.println(circle2.circumference());
		System.out.println(circle2.toString());
		
		
		circle2.setRadius(3);
		System.out.println(circle2.getRadius());
		System.out.println(circle2.area());
		System.out.println(circle2.circumference());
		
		Circle circle3 = new Circle(3);
		System.out.println(circle3.equals(circle2));
		

	}

}

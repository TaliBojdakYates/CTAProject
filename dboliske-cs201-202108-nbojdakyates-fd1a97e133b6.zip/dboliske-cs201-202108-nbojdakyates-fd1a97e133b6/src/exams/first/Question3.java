package exams.first;

import java.util.Scanner;

public class Question3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		String[] words = new String[5];
	
		for(int i=0;i<words.length;i++) {
			System.out.println("Please enter word number " + (i+1));
			String wordEntered = input.nextLine();
			words[i] = wordEntered;
		}
		
		String last = words[0];
		
		
		for(int i=1; i<words.length;i++) {
			if(words[i].compareToIgnoreCase(last)> 0) {
				last = words[i];
			}
			
		}
		input.close();
		System.out.println("The last words alphabetically is " + last);

	}

}

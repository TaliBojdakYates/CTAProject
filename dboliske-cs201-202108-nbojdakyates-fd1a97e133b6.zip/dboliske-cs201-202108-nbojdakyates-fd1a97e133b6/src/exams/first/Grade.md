# Total

100/100

# Break Down

- Question One: 25/25
  - Compiles: 5/5
  - Input: 5/5
  - Selection Structure: 10/10
  - Results: 5/5

- Question Two: 25/25
  - Compiles: 5/5
  - Input: 5/5
  - Repetition Structure: 5/5
  - Returns: 5/5
  - Formatting: 5/5

- Question Three: 25/25
  - Compiles: 5/5
  - Input: 5/5
  - Array: 5/5
  - Exit: 5/5
  - Results: 5/5

- Question Four: 25/25
  - Variables: 5/5
  - Constructors: 5/5
  - Accessors and Mutators: 5/5
  - toString and equals: 5/5
  - Other methods: 5/5

# Comments

1. Perfect
2. Perfect
3. Perfect
4. Perfect

Very Well Done!

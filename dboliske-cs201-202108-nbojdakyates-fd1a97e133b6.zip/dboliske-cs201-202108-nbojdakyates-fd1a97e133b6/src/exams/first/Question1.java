package exams.first;

import java.util.Scanner;

public class Question1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter an integer");
		int userNumber = input.nextInt();
		
		if((userNumber % 3 ==0) && (userNumber % 5 != 0)) {
			System.out.println("foo");
		}else if((userNumber % 5 ==0) && (userNumber % 3 !=0)) {
			System.out.println("bar");
		}else if ((userNumber % 3 ==0) && (userNumber % 5 ==0)) {
			System.out.println("foobar");
		}
		
		input.close();
		
	}

}

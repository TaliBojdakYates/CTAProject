package exams.first;

public class Circle {
	private double radius;
	
	public Circle() {
		radius = 1;
	}
	
	public Circle(double radius) {
		if(radius > 0) {
			this.radius = radius;
		}else {
			this.radius = 1;
			System.out.println("Radius set to 1 because negative radius entered. Please enter a postivie number");
		}
	}
	
	public void setRadius(double radius) {
		if(radius > 0) {
			this.radius = radius;
	
		}
	}
	public double getRadius() {
		return radius;
	}
	public String toString() {
		return "The circle has a radius of " + this.radius;
	}
	public boolean equals(Circle circle) {
		if(circle.getRadius() != this.radius) {
			return false;
		}else {
			return true;
		}
	}
	public double area() {
		return (3.14 * radius * radius);
	}
	public double circumference () {
		return (2*3.14* radius);
	}

}

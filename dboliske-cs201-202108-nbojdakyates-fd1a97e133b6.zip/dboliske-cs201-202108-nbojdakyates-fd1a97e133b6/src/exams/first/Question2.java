package exams.first;

import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		int counter = 0;
		double total = 0;
		boolean quit = false;
		
		do {
			System.out.println("Please enter a postive number or enter -1 to exit");
			double number = input.nextDouble();
			
			if(number != -1) {
				total += number;
				counter++;
			}else{
				quit = true;
			}
			
		}while(!quit);
		
		input.close();
		
		if(counter == 0) {
			System.out.println("No numbers entered");
		}else{
			System.out.print("The average is " + total/counter);
		}
	}

}

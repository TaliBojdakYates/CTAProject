package labs.lab4;

public class PhoneNumber {
	
	private String countryCode; //creates instance variable 
	private String areaCode; //creates instance variable
	private String number; //creates instance variable
	
	public PhoneNumber() { //set default constructor
		countryCode = "0"; //sets country code to 0
		areaCode = "000"; //sets area code to 000
		number = "0000000"; //sets number to 0000000
	}
	
	public PhoneNumber(String countryCode, String areaCode, String number) { //creates a non-default constructor  
		this.countryCode = countryCode; //sets country code to parameter country code
		this.areaCode = areaCode;// sets area code to parameter area code
		this.number = number;// sets number to parameter number
	}
	
	public String getCountryCode() { //country code getter
		return countryCode; //return country code
	}
	public String getAreaCode() { //area code getter
		return areaCode;//returns area code
	}
	public String getNumber() {//number getter
		return number; // returns number
	}
	
	public void setCountryCode(String countryCode) { // creates setter for country code
		this.countryCode = countryCode;// sets country code to parameter country code
	}
	
	public void setAreaCode(String areaCode) { //creates a setter for area code
		this.areaCode = areaCode; // sets area code to parameter area code
	}
	
	public void setNumber(String number) { //creates a setter for number
		this.number = number; // sets number to parameter number
	}
	
	public String toString() { // creates toString method
		return ("+" + this.countryCode + "(" + this.areaCode + ")" + this.number.substring(0,3)//prints out the country code area code and number if correct format
		+ "-" + this.number.substring(3,7)); //substring allows for only certain elements of the number to be used
	}
	
	public boolean correctAreaCode() { //checks if the area code is the correct length
		if(areaCode.length() ==3) {
			return true; //if it is 3 numbers then returns true
		}else {
			return false; //if it is not 3 numbers returns false
		}
	}
	
	public boolean correctNumber() { // checks if the number length is correct
		if(number.length() ==7) { //if the number has seven digits
			return true; //return true
		}else {
			return false;// else return false
		}
	}
	
	public boolean bothCorrect() { // checks if both the number and the area code are correct 
		if(correctNumber() && correctAreaCode()) { //if both are true
			return true; //return true
		}else {
			return false; //else return false
		}
	}
	
	
	
	
}

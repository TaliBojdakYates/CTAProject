## Total ##
20/20

## Break Down ##
* Part I GeoLocation
  * Exercise 1-10       8/8
  * Application Class   1/1
* Part II PhoneNumber
  * Exercise 1-10       8/8
  * Application Class   1/1
* Documentation         2/2

## Comments ##

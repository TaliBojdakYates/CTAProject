package labs.lab4;

public class instancesGeoLocation {

	
	public static void main(String[] args) {
		GeoLocation location1 =new GeoLocation(); //creates a new geolocation
		System.out.println(location1.toString()); //prints out location1 using the toSting method
		System.out.println(location1.getLat()); //prints out the lat
		System.out.println(location1.getLng()); //prints out the lng
		
		GeoLocation location2 = new GeoLocation(41.8349,87.6270); //creates new geolocation object and defines it lat and lng
		System.out.println(location2.toString()); //prints out lat and lng using toString
		System.out.println(location2.getLat()); //prints out the lat
		System.out.println(location2.getLng()); //prints out the lng
		
		location2.setLat(50.00); //sets the lat
		location2.setLng(180); //sets the lng
		System.out.println(location2.toString()); //prints out geolocation2 with correct format
	}

}

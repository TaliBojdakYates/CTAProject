package labs.lab4;

public class GeoLocation { // creates new class called GeoLocation
	private double lat; //new instance variable
	private double lng; //new instance variable
	
	
	public GeoLocation() { //default constructor
		this.lat = 0; //sets lat to 0
		this.lng = 0;	//sets lng to 0	
	}
	
	public GeoLocation(double lat, double lng) { //non default constructor
		this.lat = lat; //sets lat to parameter lat
		this.lng = lng; //sets lng to parameter lng
	}
	
	public double getLat() { //get lat method is created
		return lat; //returns the lat
	}
	
	public double getLng() { //get lng method is created
		return lng; //returns lng
	}
	
	public void setLng(double lng) { //creates the set lng method
		if(-180<=lng && lng<=180) { //checks if lng is between -180 and 180
			this.lng = lng; //sets the lng to the parameter lng entered
		}
	}
	
	public void setLat(double lat) { //creates set lat method
		if(-90<lat && lat<90) {//sets the lat to the parameter lat entered
			this.lat = lat;// sets the lat to the parameter lat entered
		}
	}
	
	public String toString() { //creates a toString method
		return ("(" + this.lat + "," + this.lng + ")"); //sets the correct format for the lat and lng
	}
	public boolean latRange() { //checks if the lat is in the correct range
		if(-90<lat && lat<90) { // if lat is bretween -90 and 90 
			return true; //returns true
		}else {
			return false; //else returns false
		}
	}
	
	public boolean lngRange() { //going to check if lng range is correct
		if(-180<=lng && lng<=180) { //if it is between -180 vand 180
			return true; //return true
		}else {
			return false; //return false
		}
	}
}

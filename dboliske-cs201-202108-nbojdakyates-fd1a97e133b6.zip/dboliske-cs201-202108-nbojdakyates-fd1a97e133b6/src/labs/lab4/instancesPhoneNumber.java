package labs.lab4;

public class instancesPhoneNumber {

	
	public static void main(String[] args) {
		PhoneNumber number1 = new PhoneNumber(); //create a new number object
		System.out.println(number1.toString());  //prints the toString method of number 
		number1.setAreaCode("510");//sets the area code of number1 to 510
		number1.setCountryCode("1"); //sets the country code to 1
		number1.setNumber("8534810"); //sets the phone number to 8534810
		
		System.out.println(number1.toString()); //prints out to string 
		System.out.println(number1.getAreaCode()); //prints out the area code
		System.out.println(number1.getCountryCode()); //prints out the country code
		System.out.println(number1.getNumber()); //prints out the number
		
		PhoneNumber number2 = new PhoneNumber("1","418","5533312"); //create a new phone number object and sets area code, country code, and number
		
		System.out.println(number2.toString()); //prints out total phone number by calling toString
		System.out.println(number2.getAreaCode()); //prints out the area code
		System.out.println(number2.getCountryCode()); //prints out the country code
		System.out.println(number2.getNumber()); //prints out the phone number
		
		System.out.println(number2.correctAreaCode()); //checks if the area code is correct
		System.out.println(number2.correctNumber()); //checks if the phone number is correct
		System.out.println(number2.bothCorrect()); //checks if both area code and number is correct
		
	
	}

}

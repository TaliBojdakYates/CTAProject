package labs.lab6;


import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class TripApp {

	public static void main(String[] args) {
		ArrayList<Trip> trip = readExistingFile();
		Scanner input = new Scanner(System.in);
	
		
		boolean quit = false;
		
		do {
			menu();
			System.out.println("Choice");
			String choice = input.nextLine();
			System.out.println();
			switch(choice) {
				case "1": 
					trip = addTrip(trip, createTrip(input));
					break;
				case "2":
					trip = removeTrip(trip,input);
					break;
				case "3" :
					ArrayList<Trip> temp = viewTrip(trip,input);
					
						for(int i = 0; i<temp.size();i++ ) {
							System.out.println(temp.get(i).toString());
						}
					
					break;
				case "4":
					trip = takeAllTrips(trip);
					break;
				case "5":
					quit = true;
					break;
				default:
					System.out.println("Sorry I did not get that");
					
					
			}
			
			
		}while(!quit);
		
		saveData(trip);
		
		System.out.println("Bye");
		

	}
	
	public static void menu(){
		System.out.println();
		System.out.println("1. Add New Trip");
		System.out.println("2. Remove Trip");
		System.out.println("3. View Trip");
		System.out.println("4. Take All Trips");
		System.out.println("5. Exit");
	}
	
	public static ArrayList<Trip> readExistingFile() {
		
		ArrayList<Trip> trip = new ArrayList<>();
		
		try {
			File in = new File("src/labs/lab6/travel.csv");
			Scanner input = new Scanner(in);
			
			
			while(input.hasNextLine()) {
				try {
					String line = input.nextLine();
					String[] values = line.split(",");
					Trip i = null;
					
					if(values[0].equalsIgnoreCase("Flight")) {
						i = new Flight(values[1],values[2],Double.parseDouble(values[3]), Boolean.parseBoolean(values[4]));
					}else if(values[0].equalsIgnoreCase("Train")) {
						String[] stops = values[4].split("/");
						
						i = new Train(values[1],values[2],Double.parseDouble(values[3]), stops);
					}else if(values[0].equalsIgnoreCase("Drive")) {
						i = new Drive(values[1],values[2],Double.parseDouble(values[3]), Double.parseDouble(values[4]));
					}else {
						System.out.print("");
					}
					
					if(i != null) {
						trip = addTrip(trip, i);
					}
						
				}catch(Exception e) {
					System.out.println("Error reading row");
				}
			
			}
			input.close();	
		}catch(Exception e) {
			System.out.println("Error reading file");
		}
		
		return trip;
			
	}
	
	public static void saveData(ArrayList<Trip> trip) {
		try {
			FileWriter out = new FileWriter("src/labs/lab6/travel.csv");
			
			for (int i=0; i<trip.size(); i++) {
				out.write(trip.get(i).toString() + "\n");
				out.flush();
			}
			out.close();
			
		}catch (Exception e) {
		}
	}

	
	public static Trip createTrip(Scanner input) {
		Trip i = null;
		
		System.out.println("Add new trip:");
		System.out.println("1. Flight");
		System.out.println("2. Drive");
		System.out.println("3. Train");
		
		String choice = input.nextLine();
		
		
		if(Integer.parseInt(choice) == 1) {
			System.out.println("Origin: ");
			String userOrigin = input.nextLine();
			System.out.println("Destination: ");
			String userDestination = input.nextLine();
			System.out.println("Duration in hours: ");
			Double userDuration = Double.parseDouble(input.nextLine());
		
			System.out.println("Meal: ");
			Boolean userMeal = Boolean.parseBoolean(input.nextLine());
			i = new Flight(userOrigin, userDestination, userDuration,userMeal);
		}else if(Integer.parseInt(choice) == 2){
			System.out.println("Origin: ");
			String userOrigin = input.nextLine();
			System.out.println("Destination: ");
			String userDestination = input.nextLine();
			System.out.println("Duration in hours: ");
			Double userDuration = Double.parseDouble(input.nextLine());
			System.out.println("Gas amount: ");
			double userGas = Double.parseDouble(input.nextLine());
			i = new Drive(userOrigin, userDestination, userDuration, userGas);
			
		}else if(Integer.parseInt(choice) == 3) {
			System.out.println("Origin: ");
			String userOrigin = input.nextLine();
			System.out.println("Destination: ");
			String userDestination = input.nextLine();
			System.out.println("Duration in hours: ");
			Double userDuration = Double.parseDouble(input.nextLine());
		
			System.out.println("Stops: using / inbetween stops");
			String userStops = input.nextLine();
			String[] stops = userStops.split("/");
			i = new Train(userOrigin, userDestination, userDuration, stops);
			
		}else {
			System.out.println("Enter a correct method of travel");
		}
		
		return i;

	}
	
	
	public static ArrayList<Trip> viewTrip(ArrayList<Trip> trip, Scanner input){
		ArrayList<Trip> temp = new ArrayList<>();
		
		if(trip.size() == 0) {
			System.out.println("No Trips");
			return null;
		}else if(trip.size() == 1) {
			return trip;
		}else {	
			
			System.out.println("Enter the type of trip");
			String type = input.nextLine();
			
			if(type.equalsIgnoreCase("Flight")){
				
				System.out.println("Enter the origin of the trip");
				String origin = input.nextLine();
				
				System.out.println("Enter the destination of the trip");
				String destination = input.nextLine();
				
				
				System.out.println("Enter the duration of the trip");
				Double duration = Double.parseDouble(input.nextLine());
				
				System.out.println("Enter if the trip has a meal");
				Boolean meal = Boolean.parseBoolean(input.nextLine());
				
				for(int j = 0; j<trip.size(); j++) {
					
					if(trip.get(j) instanceof Flight) {
						Flight flight = (Flight) trip.get(j);
				
					
						if(flight.getDestination().equalsIgnoreCase(destination)) {
							
							if(flight.getOrigin().equalsIgnoreCase(origin)) {
									if(flight.getDuration() == duration) {
									
										if(flight.hasMeals() == meal) {
											
											temp.add(trip.get(j));
											
									
										}
										
								}
							}
						}
					}
					
				
				}
				
				
			}else if(type.equalsIgnoreCase("Drive")) {
			
				System.out.println("Enter the origin of the trip");
				String origin = input.nextLine();
				
				System.out.println("Enter the destination of the trip");
				String destination = input.nextLine();
				
				
				System.out.println("Enter the duration of the trip");
				Double duration = Double.parseDouble(input.nextLine());
				
				System.out.println("Enter the amount of gas");
				Double gas = Double.parseDouble(input.nextLine());
				
				for(int j = 0; j<trip.size(); j++) {
					if(trip.get(j) instanceof Drive) {
						Drive drive = (Drive) trip.get(j);
				
							if(drive.getDestination().equalsIgnoreCase(destination)) {
								if(drive.getOrigin().equalsIgnoreCase(origin)) {
									if(drive.getDuration() == duration) {
										if(drive.getGallonsOfGas() == gas) {
										
											temp.add(trip.get(j));
										}
										
								}
							}
						}
					}
				
			}
				}else if(type.equalsIgnoreCase("Train")) {
			
				System.out.println("Enter the origin of the trip");
				String origin = input.nextLine();
				
				System.out.println("Enter the destination of the trip");
				String destination = input.nextLine();
				
				System.out.println("Enter the duration of the trip");
				Double duration = Double.parseDouble(input.nextLine());
				
				System.out.println("Enter the trips stops with a / after each stop");
				String stops = input.nextLine();
				
				for(int j = 0; j<trip.size(); j++) {
					if(trip.get(j) instanceof Train) {
						Train train = (Train) trip.get(j);
				
						if(train.getDestination().equalsIgnoreCase(destination)) {
							if(train.getOrigin().equalsIgnoreCase(origin)) {
									if(train.getDuration() == duration) {
										
										if(train.stopInFormat().equalsIgnoreCase(stops)) {
											
											temp.add(trip.get(j));
										}
										
								}
							}
						}
				}
					
			}
				
			}else {
				System.out.println("Did not work");
				ArrayList<Trip> empty = new ArrayList<>();
				return empty;
			}
			
			return temp;
			
		}
	}
	
	public static ArrayList<Trip> addTrip(ArrayList<Trip> trip, Trip i) {
		trip.add(i);
		
		return trip;
	}
	public static ArrayList<Trip> removeTrip(ArrayList<Trip> trip, Scanner input) {
		ArrayList<Trip> temp = viewTrip(trip, input);
		
		
		if(temp.size() == 0) {
			System.out.println("No matching trip to remove");
		}else{
			System.out.println("Removed " + temp.get(0).toString());
				
				trip.remove(temp.get(0));
		
		}
		
		
		return trip;
	}
	
	
	
	public static ArrayList<Trip> takeAllTrips(ArrayList<Trip> trip){
		
		for (int i=0; i<trip.size(); i++) {
			System.out.println(trip.get(i).toString());
		}
	
		trip.clear();
		
		
		for (int i=0; i<trip.size(); i++) {
			System.out.println(trip.get(i).toString());
		}
		
		
	
		
		return trip;
	}
	
}

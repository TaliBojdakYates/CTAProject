package labs.lab6;

public class Flight extends Trip {
	
	private boolean meals;
	
	public Flight() {
		super();
		this.meals = false;
		
	}
	
	public Flight(String origin, String destination, double duration, boolean meal) {
		super(duration, destination, origin);
		this.meals = meal;
	}
	
	public boolean hasMeals() {
		return meals;
	}
	public boolean setMeals(boolean meals) {
		return this.meals = meals;
	}
	
	public String toString() {
			return "Flight," + this.getOrigin() + "," + this.getDestination() + "," + this.getDuration() + 	"," + meals;
	
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Flight)) {
			return false;
		}
		Flight flight = (Flight) obj;
		if(!(super.equals(flight))){
			return false;
		}else if(flight.hasMeals() != meals) {
			return false;
		}else {
			return true;
		} 
	}
	public String travel() {
		return "Trip starts from " + origin + " and goes to " + destination + " and takes " +this.getDuration() + " long" + " and your meal status is " + meals;
	}
	

}


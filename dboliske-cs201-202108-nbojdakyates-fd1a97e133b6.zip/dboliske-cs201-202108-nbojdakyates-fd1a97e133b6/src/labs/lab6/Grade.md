## Total

20/20

## Break Down

Travel Application

- Loops to display options          2/2
- Can create a trip                 4/4
- Can remove a trip                 4/4
- Can take all trips                4/4
- Use ArrayLists instead of Arrays  6/6

## Comments


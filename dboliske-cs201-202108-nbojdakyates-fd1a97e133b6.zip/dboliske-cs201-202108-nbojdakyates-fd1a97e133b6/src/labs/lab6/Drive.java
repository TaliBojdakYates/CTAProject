package labs.lab6;

public class Drive extends Trip{
	
	private double gallonsOfGas;
	
	public Drive() {
		super();
		gallonsOfGas = 0;
	}
	
	public Drive(String origin, String destination, double duration, double gallonsOfGas) {
		super(duration,destination,origin);
		if(gallonsOfGas > 0) {
			this.gallonsOfGas = gallonsOfGas;
		}else {
			this.gallonsOfGas = 0;
			System.out.println("Enter a positive  number of gallons of gas. Gallons of gas set to 0");
		}
	}
	public double getGallonsOfGas() {
		return gallonsOfGas;
	}
	public void setGallonsOfGas(double gallonsOfGas) {
		this.gallonsOfGas = gallonsOfGas;
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Drive)) {
			return false;
		}
		Drive drive = (Drive) obj;
		if(!(super.equals(drive))) {
			return false;
		}else if(drive.getGallonsOfGas() != this.gallonsOfGas) {
			return false;
		}else {
			return true;
		}
	}
	
	public String toString() {
		return "Drive," + this.getOrigin() + "," + this.getDestination() + "," + this.getDuration() + 	"," + this.gallonsOfGas;
	}
	
	public String travel() {
		return "Trip starts from " +this.origin + " and goes to " + this.destination + " and takes " + this.getDuration() + " long and take " + gallonsOfGas + " gallons of gas";
	}

}

package labs.lab0;

public class Main {

	public static void main(String[] args) {
		System.out.println("Hello World!"); // prints hello world
		
		String name = "Tali"; // creates name variable and sets it to Tali
		String birthdate = "Feb 5 2003"; // creates birthdate variable and sets it to Feb 5 2003
		
		System.out.println("My name is " + name + " and my birthday is " + birthdate); // prints out message with name and birthday

	}

}
package labs.lab0;

public class Square {

	public static void main(String[] args) {
		//create a loop that prints the message 'x x x x' five times in a row.  
		
		
		for(int i=0; i<5; i++) { // creates a loop that runs 4 times
			System.out.println("x x x x"); // prints out the message x x x x 
		}
		
		//yes I got the correct result because it looped through the message 4 times 
		//printing a new line for each message creating a square. 

	}

}

## Total

20/20

## Break Down

Trip
- Abstraction           1/1
- Variables             1/1
- Methods               2/2

Flight
- Inheritance           1/1
- Methods               2/2

Train
- Inheritance           1/1
- Methods               2/2

Drive
- Inheritance           1/1
- Methods               2/2

Travel Application
- Loops to display menu 2/2
- Take Trips            2/2
- Create Trip           2/2
- Exits                 1/1

## Comments

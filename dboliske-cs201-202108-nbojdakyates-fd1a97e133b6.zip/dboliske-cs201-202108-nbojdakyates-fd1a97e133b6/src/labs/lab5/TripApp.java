package labs.lab5;


import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class TripApp {

	public static void main(String[] args) {
		Trip[] trip = readExistingFile();
		Scanner input = new Scanner(System.in);
		
		boolean quit = false;
		
		do {
			menu();
			System.out.println("Choice");
			String choice = input.nextLine();
			System.out.println();
			switch(choice) {
				case "1": 
					trip = addTrip(trip, createTrip(input));
					break;
				case "2":
					trip = takeAllTrips(trip);
					break;
				case "3":
					quit = true;
					break;
				default:
					System.out.println("Sorry I did not get that");
					
					
			}
			
			
		}while(!quit);
		
		saveData(trip);
		
		System.out.println("Bye");
		

	}
	
	public static void menu(){
		System.out.println();
		System.out.println("1. Add New Trip");
		System.out.println("2. Take All Trips");
		System.out.println("3. Exit");
	}
	
	public static Trip[] readExistingFile() {
		
		Trip trip[] = new Trip[0];
		
		try {
			File in = new File("src/labs/lab5/travel.csv");
			Scanner input = new Scanner(in);
			
			
			while(input.hasNextLine()) {
				try {
					String line = input.nextLine();
					String[] values = line.split(",");
					Trip i = null;
					
					if(values[0].equalsIgnoreCase("Flight")) {
						i = new Flight(values[1],values[2],Double.parseDouble(values[3]), Boolean.parseBoolean(values[4]));
					}else if(values[0].equalsIgnoreCase("Train")) {
						String[] stops = values[4].split("/");
						
						i = new Train(values[1],values[2],Double.parseDouble(values[3]), stops);
					}else if(values[0].equalsIgnoreCase("Drive")) {
						i = new Drive(values[1],values[2],Double.parseDouble(values[3]), Double.parseDouble(values[4]));
					}else {
						System.out.print("");
					}
					
					if(i != null) {
						trip = addTrip(trip, i);
					}
						
				}catch(Exception e) {
					System.out.println("Error reading row");
				}
			
			}
			input.close();	
		}catch(Exception e) {
			System.out.println("Error reading file");
		}
		
		return trip;
			
	}
	
	public static void saveData(Trip[] trip) {
		try {
			FileWriter out = new FileWriter("src/labs/lab5/travel.csv");
			
			if(trip.length <5) {
				for (int i=0; i<trip.length; i++) {
					out.write(trip[i].toString() + "\n");
					out.flush();
				}
			}else {
				for (int i=0; i<5; i++) {
					out.write(trip[i].toString() + "\n");
					out.flush();
					}
			}
			out.close();
			
		}catch (Exception e) {
		}
		
	}

	
	public static Trip createTrip(Scanner input) {
		Trip i = null;
		
		System.out.println("Add new trip:");
		System.out.println("1. Flight");
		System.out.println("2. Drive");
		System.out.println("3. Train");
		
		String choice = input.nextLine();
		
		
		if(Integer.parseInt(choice) == 1) {
			System.out.println("Origin: ");
			String userOrigin = input.nextLine();
			System.out.println("Destination: ");
			String userDestination = input.nextLine();
			System.out.println("Duration in hours: ");
			Double userDuration = Double.parseDouble(input.nextLine());
		
			System.out.println("Meal: ");
			Boolean userMeal = Boolean.parseBoolean(input.nextLine());
			i = new Flight(userOrigin, userDestination, userDuration,userMeal);
		}else if(Integer.parseInt(choice) == 2){
			System.out.println("Origin: ");
			String userOrigin = input.nextLine();
			System.out.println("Destination: ");
			String userDestination = input.nextLine();
			System.out.println("Duration in hours: ");
			Double userDuration = Double.parseDouble(input.nextLine());
			System.out.println("Gas amount: ");
			double userGas = Double.parseDouble(input.nextLine());
			i = new Drive(userOrigin, userDestination, userDuration, userGas);
			
		}else if(Integer.parseInt(choice) == 3) {
			System.out.println("Origin: ");
			String userOrigin = input.nextLine();
			System.out.println("Destination: ");
			String userDestination = input.nextLine();
			System.out.println("Duration in hours: ");
			Double userDuration = Double.parseDouble(input.nextLine());
		
			System.out.println("Stops: using / inbetween stops");
			String userStops = input.nextLine();
			String[] stops = userStops.split("/");
			i = new Train(userOrigin, userDestination, userDuration, stops);
			
		}else {
			System.out.println("Enter a correct method of travel");
		}
		
		return i;

	}
	
	public static Trip[] addTrip(Trip[] trip, Trip i) {
		Trip[] temp = new Trip[trip.length + 1];
		
		if(trip.length < 5) {
			for(int j=0; j<trip.length; j++) {
				temp[j] = trip[j];
			}
			 trip = temp;
			 trip[temp.length-1] = i;
			}
		
		 return trip;
	}
	
	
	public static Trip[] takeAllTrips(Trip[] trip){
		if(trip.length <5) {
			for (int i=0; i<trip.length; i++) {
				System.out.println(trip[i].toString());
			}
		}else {
			for (int i=0; i<5; i++) {
				System.out.println(trip[i].toString());
				}
		}
		Trip[] temp = new Trip[0];
		return trip= temp;
		
	}
	
}

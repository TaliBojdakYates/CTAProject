package labs.lab5;

public class Train extends Trip{
	
	private String[] stops;
	
	
	
	public Train() {
		super();
		stops[0] = "None";
	}
	
	public Train(String origin, String destination, double duration, String[] stops) {
		super(duration, destination, origin);
		this.stops = stops;
	}
	
	public String[] getStops(){
		return this.stops;
	}
	
	public String stopInFormat() {
		String stringStops = "";
		for(int i=0;i<this.stops.length;i++) {		
			stringStops = stringStops.concat(stops[i] + "/");
		} 
		
		return stringStops;
	}

	public void setStops(String[] stops) {

		this.stops = stops;
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Train)) {
			return false;
		}
		
		Train train = (Train)obj;
		if(!(super.equals(train))){
			return false;
		}else if(train.getStops() != stops) {
			return false;
		}else {
			return true;
		}
	}
	
	
	public String toString() {
		return "Train," + this.getOrigin() + "," + this.getDestination() + "," + this.getDuration() + 	"," + stopInFormat();
	}
	
	public String travel() {
		return "Trip starts from " + this.getOrigin() + " and goes to " + this.getDestination()+ " and takes " + this.getDuration() + " long and has the following stops " + stopInFormat();
	}
}

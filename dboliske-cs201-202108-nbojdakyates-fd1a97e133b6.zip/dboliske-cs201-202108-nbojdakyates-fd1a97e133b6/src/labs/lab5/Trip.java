package labs.lab5;

public abstract class Trip {
	
	private double duration;
	protected String destination;
	protected String origin;
	
	public Trip() {
		duration = 0;
		destination = "Oakland";
		origin = "Chicago";
	}
	
	public Trip(double duration, String destination, String origin) {
		if(duration > 0) {
			this.duration = duration;
		}else {
			this.duration = 0;
			System.out.println("Duration set to 0. Please enter a postive duration");
		}
		this.destination = destination;
		this.origin = origin;
	}
	
	public double getDuration() {
		return duration;
	}
	public String getDestination() {
		return destination;
	}
	public String getOrigin() {
		return origin;
	}
	
	public void setDuration(double duration) {
		if(duration > 0) {
			this.duration = duration;
		}
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	
	public boolean equals(Object obj) {
		if(!(obj instanceof Trip)) {
			return false;
		}
		 
		Trip trip = (Trip) obj;
		
		if(trip.getDuration() != this.duration) {
			return false;
		}else if(trip.getDestination() != this.destination) {
			return false;
		}else if(trip.getOrigin() != this.origin) {
			return false;
		}else {
			return true;
		}
	}
	
	public String toString() {
		return "Destination: " + destination + "	Origin: " + origin + "	Duration: " + duration;
	}
	
	public abstract String travel();

	
	

}

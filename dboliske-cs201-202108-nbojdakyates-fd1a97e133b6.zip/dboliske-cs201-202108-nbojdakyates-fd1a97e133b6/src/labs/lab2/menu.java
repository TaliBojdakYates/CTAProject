package labs.lab2;
import java.util.*;

public class menu {
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in); //creates a new scanner to take user input
		
		int option = 0; //sets the initial choice to 0 so it will print menu
		
		while(option != 4) { // loops through menu if 4 is not entered
		System.out.println("Please select a number"); //tells user to choose a number
		System.out.println("1.Say Hello"); // menu:option one is "say hello"
		System.out.println("2.Addition"); // menu: option two is addition
		System.out.println("3.Multiplication"); // menu: option three is multiplication
		System.out.println("4.Exit"); // menu: exits
		option = userInput.nextInt(); // collects the users input
		
		switch(option) {  //switch creates a switch statement passing the user input into it
			case 1: //first option that could be entered
				System.out.println("Hello"); //prints hello
				break; //exits loop
				
			case 2://second option that could be entered
				System.out.println("Enter number 1"); //asks for number one
				double number1 = userInput.nextDouble(); //saves user input for number 1
				System.out.println("Enter number 2");//asks for number two
				double number2 = userInput.nextDouble();//saves user input for number 2
				
				System.out.println(number1 + " + " + number2 + " = " + (number1+number2)); //adds number 1 and 2
				break;//exits loop
				
			case 3://third option that could be entered
				System.out.println("Enter number 1"); //asks for number one
				double number3 = userInput.nextDouble();//saves user input for number 1
				System.out.println("Enter number 2"); //asks for number two
				double number4 = userInput.nextDouble();//saves user input for number 2
				
				System.out.println(number3 + " * " + number4 + " = " + (number3*number4)); //multiplies numbers
				break;//exits loop
			case 4://fourth option that could be entered
				System.out.println("Exiting"); //says exiting when 4 is pressed
				break; //exits loop
				
			default: // is none of of the option are selected
				System.out.println("Please select a number from the table"); //asks user to enter a number from table
				break; //exits loop
					
			}
		}
		
		
	}

}

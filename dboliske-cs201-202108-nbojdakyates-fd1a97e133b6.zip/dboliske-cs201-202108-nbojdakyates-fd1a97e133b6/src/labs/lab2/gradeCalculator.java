package labs.lab2;
import java.util.*;

public class gradeCalculator {
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in); //creates a scanner and asks for user input
	
	
	
		double totalGrades = 0; //sets initial total to 0
		int numberOfGrades = 0; //sets total number of grades to 0
		double grade = 0; //sets grade to 0
		
		System.out.println("Enter grades"); //asks user to enter grades
		System.out.println("Enter -1 when done entering grades"); //tells the user how to stop program
		
		do { //loops code below
			grade = userInput.nextDouble(); //sets grade to user input
			if(grade != -1) { // only does code below is user enters -1
			numberOfGrades++; //adds one to the total number of grades entered
			totalGrades += grade; // adds grade entered to total
			}
		}while(grade != -1); // contiues loop unless grade entered is -1
		
		double averageGrade = totalGrades/numberOfGrades; // sets the average grade to all the grades entered devided by number of grades entered
		
		System.out.println("The average grade is " + averageGrade); // prints average grade
	

	}
	

}

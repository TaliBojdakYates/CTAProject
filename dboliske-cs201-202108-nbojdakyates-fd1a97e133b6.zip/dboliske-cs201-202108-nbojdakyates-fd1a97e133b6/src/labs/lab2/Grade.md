## Total ##
20/20

## Break Down ##
* Exercise 1 6/6
* Exercise 2 6/6
* Exercise 3 6/6
* Documentation 2/2

## Comments ##
Remember to close your scanners
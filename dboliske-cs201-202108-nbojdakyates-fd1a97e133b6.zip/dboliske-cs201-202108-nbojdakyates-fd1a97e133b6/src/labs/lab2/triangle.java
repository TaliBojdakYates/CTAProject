package labs.lab2;
import java.util.*;

public class triangle {
	public static void main(String[] args) {
	Scanner userInput = new Scanner(System.in); // creates a new scanner to look for user input
	
	System.out.println("Please enter triagle dimensions"); //ask for dimensions
	int dimensions = userInput.nextInt(); //saves user input as an int
	
	for(int i=0; i<dimensions; i++) { //loops through the dimensions
		
		 for(int j=0; j<=i; j++) { //for every dimension, loops through that number of times
         
             System.out.print("x "); // prints "x " on the same line how many times it loops through
		 }
		 
		 System.out.println(); // creates a new line

	}
	
	}
}
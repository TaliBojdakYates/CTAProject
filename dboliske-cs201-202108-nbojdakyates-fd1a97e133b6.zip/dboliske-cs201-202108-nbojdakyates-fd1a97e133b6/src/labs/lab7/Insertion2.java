package labs.lab7;

public class Insertion2 {

	public static void main(String[] args) {
		String[] array  = {"cat", "fat", "dog", "apple", "bat", "egg"};
		array = insertionSort(array);
		
		for(int i = 0; i<array.length;i++) {
			System.out.print(array[i] + " ");
		}

	}
	public static String[] insertionSort(String[] array) {
		for(int j = 1; j<array.length; j++) {
			int i = j;
			while(i >0 && array[i].compareTo(array[i-1]) <=0) {
				swap(array,i,i-1);
				i--;
			}
		}
		return array;
	}
	public static void swap(String[] array, int i, int j) {
		String temp = array[i];
		array[i]= array[j];
		array[j] = temp;
	}

}

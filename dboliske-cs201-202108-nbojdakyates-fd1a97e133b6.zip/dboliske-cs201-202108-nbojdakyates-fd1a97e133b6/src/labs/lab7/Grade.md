## Total

20/20

## Break Down

- Exercise 1 6/6
- Exercise 2 6/6
- Exercise 3 8/8

## Comments

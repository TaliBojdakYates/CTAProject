package labs.lab7;

import java.util.Scanner;

public class Binary3 {

	public static void main(String[] args) {
		String[] array =  {"c", "html", "java", "python", "ruby", "scala"};
		Scanner input = new Scanner(System.in);
		
		System.out.println("Search for a term");
		String userInput = input.nextLine();
		int index = search(array,userInput);
		
		if(index == -1) {
			System.out.println(userInput + " was not found");
		}else {
			System.out.println(userInput + " found at index " + index);
		}
		input.close();
	}
	
	public static int search(String[] array, String value) {
		return search(array, value, 0, array.length);
	}
	public static int search(String[] array, String value, int start, int end) {
		if(start>=end) {
			return -1;
		}
		
		int middle = (start+end)/2;
		if(array[middle].compareToIgnoreCase(value) <0) {
			return search(array, value,middle+1,end);
		}else if(array[middle].compareToIgnoreCase(value) >0) {
			return search(array,value,start,middle);
		}
		
		return middle;	
	}

}

/*width     | height	| length	| expected surface area | actual
 * 10		|10			|12			| 680					|680
 * 20		|  5		| 2			|300					|300
 * 5		|10			| 	3		| 190					|190
 * 
 */



package labs.lab1;
import java.util.*;

public class box {
	public static void main(String[] Args) {
		Scanner userInput = new Scanner(System.in); 
		
		System.out.println("Please enter a width for your box in inches"); //asks for width
		int width = userInput.nextInt();//saves user input as an int
		
		System.out.println("Please enter a length for your box in inches");//asks for length
		int length = userInput.nextInt();//saves user input as an int
		
		System.out.println("Please enter a height for your box in inches");//asks for height
		int height = userInput.nextInt();//saves user input as an int
		
		int amountOfWood = (2*height*width) + (2*height*length) + (2*length*width); // saves amount of wood needed to a variable
		System.out.println("Amount of wood needed for your box is " + amountOfWood + "in^2 of wood"); // prints out how much wood is needed
		
	}

}

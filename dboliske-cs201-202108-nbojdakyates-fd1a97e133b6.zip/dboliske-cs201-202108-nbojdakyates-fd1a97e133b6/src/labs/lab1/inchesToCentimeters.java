/*	in		| expected cm | actual
 * 10		| 25.4		  |25.4
 * 2		| 5.08		  | 5.08	
 * 150		|381		  | 381
 * 
 * 
 */


package labs.lab1;
import java.util.*;
public class inchesToCentimeters {

	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in); //new scanner is created
		
		System.out.println("Please enter inches"); //prints asking for in
		int inches = userInput.nextInt(); // saves input value
		
		double cm = inches*2.54; //coverts in to cm
		
		System.out.println(inches + " in = " + cm + "cm"); //prints cm

	}

}

package labs.lab1;
import java.util.Scanner;

public class inputAndOutput {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); //creates a new scanner for input
		System.out.println("Please enter your name"); //asks for name
		
		String userName = input.nextLine(); //saves input as name
		
		System.out.println(userName); //prints name

		
		
		
	}
}
	

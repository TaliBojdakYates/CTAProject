package labs.lab1;
import java.util.*;
public class arithmeticCalculations {

	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		
		
		
		
		System.out.println("Enter your age"); //ask for angle 
		int myAge = userInput.nextInt(); //saves user input as an int
		System.out.println("Enter your fathers age"); //asks for angle
		int fathersAge = userInput.nextInt(); //saves user input as an int
		System.out.println("Fathers age minus my age = " + (fathersAge-myAge)); // prints fathers age - yours
		
		System.out.println("Enter your birth year"); //asks for your birthyear
		int birthYear = userInput.nextInt(); //saves user input as an int
		System.out.println("Birth year times two = " + birthYear*2); //prints birth year by two
		
		System.out.println("Enter your height in inches"); //asks for height
		int heightInches = userInput.nextInt(); //saves user input as an int
		System.out.println("My height in inches to cm = " + heightInches*2.54); //2.54cm per 1 inch
		System.out.println("My height from inches to feet and inches " + Math.floor(heightInches/12) + " feet and " + heightInches%12 + " in");
		//convers in to in and ft by deviding by 12 and the remainder is in
		
		}
}

/*
 * F			Exp C		Actual 
 * 	32		|		0	| 	0
 * 	10		|	-12.2	| -12.222
 * 	-10		|	-23.3333| 	-23.3333
 * 
 *  C			Exp F		Actual F
 * 	0		|		32	|	32
 * 	-12.222	|	10		|	10
 * 	40		|	104		|	104
 * 
 * I am happy with the results it worked and converted the temps correctly.
 */
package labs.lab1;
import java.util.Scanner;

public class tempConversion {
	
	public static void main(String[] args) {
		
	
	Scanner userInput = new Scanner(System.in); //creates a new scanner to look for input
	
	System.out.println("Please enter Fahrenheit"); //ask user for f
	double tempF = userInput.nextDouble(); //saves input value
	System.out.println(tempF + " fahrenheit is " + ((tempF-32) * 5/9) + " celcius"); //converts f to c and prints it out
	
	System.out.println("Please enter celcius"); //ask for c
	double tempC = userInput.nextDouble(); // saves input value
	System.out.println(tempC + " celcius is " + ((tempC* 9/5) + 32) + " fahrenheit"); //prints c to f and prints is out
	
	}
}

package labs.lab1;
import java.util.Scanner;

public class keyboardInput {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); //creates a new scanner for input
		System.out.println("Please enter your first name"); //asks for first name
		
		String userName = input.nextLine(); //saves name from input
		char firstLetter = userName.charAt(0); // gets the first letter of the name
		
		System.out.println(firstLetter); //prints first letter

	}

}

## Total

19/20

## Break Down

* Exercise 1    6/6
* Exercise 2    5/6
* Exercise 3    6/6
* Documentation 2/2

## Comments
Exercise 2 - Did not use try/catch to catch wrong input
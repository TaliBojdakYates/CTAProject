package labs.lab3;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class userArray {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); // creates a scanner for user input
		
		double[] numbers = new double[0]; // creates an array that starts with no values
		
		boolean exit = false; //exit loop variable

		
		do{
			System.out.println("Enter a number or exit"); //asks user to enter a number or exit
			String userTemp = input.nextLine(); //saves what was entered from keyboard to variable 
			if(userTemp.equals("Done")) { //checks if it equals "Done
					exit = true; //if it does exit loop
				
			}else {
				double[] temp = new double[numbers.length +1]; // makes a new array that is one greater than numbers
				for(int i=0; i<numbers.length; i++) {
					temp[i] = numbers[i]; //loops through numbers array making temp have its same its values 
				}
				temp[numbers.length] = Double.parseDouble(userTemp); //the extra index in temp has the extra value entered
			
				numbers = temp; //sets number array to temp
			}
		}while(!exit);
		
		
		
		System.out.println("Create name of file to save values to"); //asks user for file name
		
		String fileName = "src/labs/lab3/" +input.nextLine(); // creates the file name string
		
		try {
			
			File file = new File(fileName); //makes the file with name given
			FileWriter userFile = new FileWriter(file); //creates a fileWriter
			
			for(int i =0; i<numbers.length;i++) {

				String s=Double.toString(numbers[i]);	 //loops through the values in the array numbers and turns into a string
	
				userFile.write(s+ "\n"); //writes the string to the file
			}
		
			userFile.close(); //closes file
		}catch(IOException e) { //catchs file error
			System.out.println("File error please try again"); //prints informative message
		}
		
		
		
		
		
	}

}

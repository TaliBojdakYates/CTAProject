package labs.lab3;

public class findMin {
	public static void main(String[] args) {
		int[] givenArray = {72, 101, 108, 108, 111, 32, 101, 118, 101, 114, 121, 111, 110, 101, 33, 32, 76, 111, 111, 107, 32, 97, 116, 32, 116, 104, 101, 115, 101, 32, 99, 111, 111, 108, 32, 115, 121, 109, 98, 111, 108, 115, 58, 32, 63264, 32, 945, 32, 8747, 32, 8899, 32, 62421};
		//makes the given array
		int min = givenArray[0]; // sets the minimum value to the first element in the array
		for(int i=0; i<givenArray.length; i++) { //loops through the array
			if(givenArray[i] < min) { //if the index value in the array is less than the set min value 
				min = givenArray[i]; //it sets the minimum value to that value
			}
		}
		System.out.println(min); //prints out the min
	
	}

}

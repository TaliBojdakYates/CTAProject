package labs.lab3;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.Scanner;
//import needed things

public class averageGrade {
	public static void main(String[] args) {
	
	
	String[] names = new String[14]; //array of names that holds 14 elements because that is how many there are in the file
	double[] grades = new double[14]; //array of grades that holds 14 elements because that is how many there are in the file
	int count = 0; // sets a counter variable to 0
	
	try {
		File file = new File("src/labs/lab3/grades.csv"); // makes a file object
		Scanner students = new Scanner(file); // reads file
		
		while(students.hasNext() && count < names.length) { // while the file has another row keep looping
			String line = students.nextLine(); // sets line to the next line in file
			String values[] = line.split(","); // splits the line up into two section at the ','
		
			names[count] = values[0]; //saves the first elements to name array
			grades[count] = Double.parseDouble(values[1]); //saves second elements to grade array
			count++; //moves to the next element in the array
			
	}
	}catch(IOException e) { //catches file error
		System.out.println("No file found"); //prints no file found
	}
	
	double total = 0; //initially sets total to 0
	for(int i=0; i<grades.length;i++) { //loops through all the grades in the array
		total += grades[i]; // adds the grade at index i to the total
	}
	System.out.println("The average grade is " + total/grades.length); //prints total/number of grades for average

	}
}

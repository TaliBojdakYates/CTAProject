# CS 201

This repository will contain all assignments, exams, and projects that you will be working on throughout the semester. There may not be much in it at the start, but more will be added as time goes on, including additional work as well as grades for completed work.

## Course Information

This course has additional information and resources available on the [course website](http://mypages.iit.edu/~dboliske) and int the [course lecture repository](https://bitbucket.org/dboliske/cs201-202108-lectures/src/master/).

### Questions?

For questions about your grades, please contact your [TA](mailto:aidrees1@hawk.iit.edu).

If you have any issues using your repository, please email me at [dboliske@hawk.iit.edu](mailto:dboliske@hawk.iit.edu) or talk to me after class.
